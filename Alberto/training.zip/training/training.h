#ifndef UTILITIES_H
#define UTILITIES_H

#include <iostream>
#include <fstream>
#include <string>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include "opencv2/imgproc.hpp"
#include "opencv2/highgui.hpp"


cv::Mat preprocessing(cv::Mat input);

void negative_dataset(std:: string path);

void generate_neg_file(std::string path);

#endif