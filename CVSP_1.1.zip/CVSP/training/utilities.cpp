/*Functions that were used in order to generate the negative samples for the training purpose.
For the final usage of the project they are not required, but if the user wants to used them there are
some requirements to follow:
-EgoHands dataset;
-folders.txt file containing every subfolder of the EgoHands dataset that the user wants to select as negative;
-Generate a "negative" folder for the output images; 
*/

#include "training.h"

using namespace std;

using namespace cv;


// @Alberto Makosa
Mat preprocessing(Mat input) {
	Mat tmp;
	blur(input, tmp, Size(5, 5));

	cvtColor(tmp, tmp, COLOR_BGR2HSV);

	inRange(tmp, Scalar(0, 30, 60), Scalar(20, 150, 250), tmp);

	erode(tmp, tmp, getStructuringElement(MORPH_ELLIPSE, Size(3, 3)));

	dilate(tmp, tmp, getStructuringElement(MORPH_ELLIPSE, Size(11, 11)));

	return tmp;

}


// @Alberto Makosa
void generate_neg_file(std::string path)
{
	string folder(path);
	vector<string> filenames;

	glob(folder, filenames);

	ofstream negative;

	negative.open("neg.txt");


	for (int i = 0; i < filenames.size(); i++) {
		
		negative << filenames[i] << "\n";
	}

	negative.close();
}

// @Alberto Makosa
void negative_dataset(string path) {
	ifstream file("folders.txt");
	string str, outpath("negative/");
	int id = 0;
	
	Mat img, tmp;
	while (getline(file, str)) {
		string prefix(path+str);
		string paths = prefix + SUFFIX;
		string folder(paths);
		vector<string> filenames;

		glob(paths, filenames);

		for (int i = 0; i < filenames.size(); i++) {
			Mat out;
			stringstream ss;
			ss << i+id*100;
			img = imread(filenames[i]);
			tmp = preprocessing(img);
			bitwise_not(tmp, tmp);
			bitwise_and(img, img, out, tmp);
			outpath = outpath + ss.str() + ".jpg";
			imwrite(outpath, out);

			outpath = "negative/";
		}
		id++;
	}
}
