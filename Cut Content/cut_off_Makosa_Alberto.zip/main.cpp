///@name Alberto Makosa
#include "utilities.h"
#include "my_cascade.h"
#include "segmentation.h"
#include "CVSPfunctions.h"

using namespace std;
using namespace cv;

int main(int argc, char** argv) {

	string path = "negative/*.jpg";
	cv::Mat hand_img = cv::imread("test_hand.png");
	string path2 = "neg2/";
	string path3 = "test/";
	vector<Mat> hands;
	instance inst;
	Mat test;
	int neg = 4699;

	read_input(&inst, argc, argv);

	upload_img(&inst);

	//img_canny(&inst);

	generate_neg_file(path);

	//negative_dataset("_LABELLED_SAMPLES");

	//for (int i = 0; i < inst.image.size(); i++) {
	//	inst.filtered[i]=preprocessing(inst.image[i]);
	//}
	
	//first_BoF_step(&inst);
	//second_BoF_step(&inst);
	bool flag = false;

	inst.hands = findHands(inst.image[7], hand_img);
	//cout << inst.hands.size() << '\n';
	//inst.IoU = evaluation("det/08.txt", inst.hands);
	hands = mask_segm(inst.hands, inst.image[7]);
	hands = color_hands(hands);
	test = gen_output(inst.image[7], hands);
	imwrite("my_segm.jpg",test);

	for (int i = 0; i < inst.image.size(); i++) {
		//cout << "precision:" << inst.IoU[i] << '\n';
		//cascade_algo(inst.image[i], inst.image[i]);
		stringstream ss;
		ss << i;
		path3 = path3 + ss.str() + ".jpg";
		imwrite(path3, meanshift(inst.image[i])); //inst.image[i]);
		path3 = "testms/";

		if (flag) {
			inst.hands = findHands(inst.image[7], hand_img);
			cout << inst.hands.size() << '\n';
			inst.IoU = evaluation("det/01.txt", inst.hands);
			hands = mask_segm(inst.hands, inst.image[7]);
			hands = color_hands(hands);
			test = gen_output(inst.image[7], hands);
			//addWeighted(inst.image[0], 0.7, inst.filtered[0], 0.3, 0.0, test);
			cascade_algo(inst.image[7], inst.image[7]);
			hands = mask_segm(inst.hands, inst.image[7]);
			hands = color_hands(hands);
			test = gen_output(inst.image[9], hands);

			imshow("tets", test);
			waitKey(0);
			ss << neg;
			path2 += ss.str();
			path2 += ".jpg";
			//cout << path2 << '\n';

		}
		
	}
	
	
	free_instance(&inst);
	


	return 0;
}