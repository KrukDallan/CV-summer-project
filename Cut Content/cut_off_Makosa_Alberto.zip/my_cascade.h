#ifndef MY_CASCADE_H
#define MY_CASCADE_H

#include "utilities.h"
#include "segmentation.h"

#define SUFFIX "*.jpg"

void generate_neg_file(std::string path);

std::vector<cv::Rect> cascade_algo(cv::Mat input_test, cv::Mat output);

void negative_dataset(std:: string path);

std::vector<float> evaluation(std::string path, std::vector<cv::Rect> hands);


#endif