///@name Leonardo Sforzin

#include "CVSPfunctions.h"


//PROBLEMS:
//1) Sift is NOT rotation invariant --> should we add vocabularies of rotated images
//2) 


//Things to add?:


//Notes: histograms are used to train a classifier, like kNearestNeighbour
// After creating the codebook with k centroids, iterate through every image used and
// search for words present both in he dictionary and in the image, then increase the count of that particular word <-- this is how histograms are created
int main(int argc, char** argv)
{
	int executionCode = 3;

	// Training of the BoW
	if (executionCode == 1)
	{
		std::string path = argv[1];
		std::vector<std::string> datasetType{ "hands", "cards", "chess", "jenga" };

		std::vector<cv::Mat> greyScale;
		int fNSize = 0;
		// load images
		std::cout << "\n" << "Loading images" << "\n";
		for (int i = 0; i < datasetType.size(); i++)
		{
			std::string fullPath = path + "\\" + datasetType[i] + "Dataset" + "/*.jpg";
			cv::String folderString(fullPath);
			std::vector<cv::String> fileNames;
			cv::glob(folderString, fileNames, false);
			fNSize += fileNames.size();
			for (int i = 0; i < fileNames.size(); i++)
			{
				cv::Mat img = cv::imread(fileNames[i], cv::IMREAD_GRAYSCALE);
				greyScale.push_back(img);
			}
			std::cout << "\n" << "Loaded dataset "<<datasetType[i] +"Dataset" << "\n";
		}
		//Features extraction
		std::vector<cv::KeyPoint> keyPoints;
		cv::Mat descriptor, features;
		cv::Ptr<cv::SiftDescriptorExtractor> extractor = cv::SiftDescriptorExtractor::create();
		// variables used to display the progress of the for loop
		int increment1 = 0.01 * fNSize;
		int countdown = increment1;
		int percent1 = 0;
		std::cout << "\n";
		//Compute the features for each image of the "training set"
		std::cout << "\n" << "Starting BoW" << "\n";
		for (int i = 0; i < fNSize; i++)
		{
			//detects features
			extractor->detect(greyScale[i], keyPoints);
			//Computes the descriptors for a set of keypoints detected in an image
			extractor->compute(greyScale[i], keyPoints, descriptor);
			//insert them in features
			features.push_back(descriptor);
			if (--countdown == 0)
			{
				percent1++;
				std::cout << "\r" << std::string(percent1, '|') << percent1 * 1 << "%";
				countdown = increment1;
				std::cout.flush();
			}
		}
		
		std::cout << "\n" << "\n" << "Features computed" << "\n";

		//Build BoW trainer
		// dictSize (dictionary size) is the "k" of kmeans
		int dictSize = 50;
		//Termination criteria
		cv::TermCriteria tc(cv::TermCriteria::Type::COUNT, 50, 0.001);
		//attempts
		int attempts = 1;
		//flags
		int flags = cv::KMEANS_PP_CENTERS;
		//create BoW trainer
		cv::BOWKMeansTrainer bowTrainer(dictSize, tc, attempts, flags);
		//cluster the feature vectors
		std::cout << "\n" << "Starting clustering" << "\n";
		cv::Mat bow = bowTrainer.cluster(features);
		//store the vocabulary
		std::cout << "\n" << "Storing the bag of visual words" << "\n";
		//cv::FileStorage fs("cards-courtyard-bt.yml", cv::FileStorage::WRITE);
		//cv::FileStorage fs("cards-livingroom-hs.yml", cv::FileStorage::WRITE);
		cv::FileStorage fs("bag-of-words.yml", cv::FileStorage::WRITE);
		fs << "vocabulary" << bow;
		fs.release();
	}
	
	if(executionCode == 2)
	{
		cv::Mat bow;
		cv::FileStorage fs("bag-of-words.yml", cv::FileStorage::READ);
		fs["vocabulary"] >> bow;
		fs.release();

		std::cout << "\n" << "Creating histograms" << "\n";

		//Preprocessing for the SVM
		//Create the histograms
		cv::Mat trainingInput;
		cv::Mat trainingLabels;

		std::vector<cv::Mat> greyScale;
		int fNSize = 0;
		std::string path = argv[1];
		std::vector<std::string> datasetType{ "hands", "cards", "chess", "jenga" };
		std::cout << "\n" << "Loading images" << "\n";
		for (int i = 0; i < datasetType.size(); i++)
		{
			std::string fullPath = path + "\\" + datasetType[i] + "Dataset" + "/*.jpg";
			cv::String folderString(fullPath);
			std::vector<cv::String> fileNames;
			cv::glob(folderString, fileNames, false);
			fNSize += fileNames.size();
			for (int i = 0; i < fileNames.size(); i++)
			{
				cv::Mat img = cv::imread(fileNames[i], cv::IMREAD_GRAYSCALE);
				greyScale.push_back(img);
			}
			std::cout << "\n" << "Loaded dataset " << datasetType[i] + "Dataset" << "\n";
		}

		for (int i = 0; i < datasetType.size(); i++)
		{
			std::cout << "\n" << "Current dataset: " << datasetType[i] << "Dataset" << "\n";

			std::string fullPath = path + "\\" + datasetType[i] + "Dataset" + "/*.jpg";
			cv::String folderString(fullPath);
			std::vector<cv::String> fileNames;
			cv::glob(folderString, fileNames, false);
			int increment5 = 0.05 * fileNames.size();
			int countdown = increment5;
			int percent5 = 0;

			int label = 1;
			for (int j = 0; j < fileNames.size(); j++)
			{
				cv::Mat img = cv::imread(fileNames[j], cv::IMREAD_GRAYSCALE);
				cv::Ptr<cv::SiftDescriptorExtractor> extractor = cv::SiftDescriptorExtractor::create();
				std::vector<cv::KeyPoint> keyPoints;
				cv::Mat descriptor;
				//detects features
				extractor->detect(greyScale[i], keyPoints);
				//Computes the descriptors for a set of keypoints detected in an image
				extractor->compute(greyScale[i], keyPoints, descriptor);

				cv::Ptr<cv::DescriptorMatcher> matcher = cv::FlannBasedMatcher::create();
				std::vector<cv::DMatch> matches;
				matcher->match(descriptor, bow, matches);
				cv::Mat histogram = cv::Mat::zeros(1, bow.rows, CV_32F);
				int index = 0;
				for (std::vector<cv::DMatch>::iterator k = matches.begin(); k < matches.end(); k++, index++)
				{
					histogram.at<float>(0, matches.at(index).trainIdx) += 1.0;
				}
				trainingInput.push_back(histogram);
				trainingLabels.push_back(cv::Mat(1, 1, CV_32SC1, label)); //CV_32SC1 is a 1 Channel of signed 32 bit integer

				if (--countdown == 0)
				{
					percent5++;
					std::cout << "\r" << std::string(percent5, '|') << percent5 * 5 << "%";
					countdown = increment5;
					std::cout.flush();
				}
			}
			label++;
		}
		//Create and train kNearest
		std::cout << "\n" << "Creating and training kNearest" << "\n";
		cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::create();
		knn->setDefaultK(50);
		//cv::Ptr<cv::ml::SVM> svm = cv::ml::SVM::create();
		/*svm->setKernel(cv::ml::SVM::LINEAR);
		svm->setTermCriteria(cv::TermCriteria(cv::TermCriteria::MAX_ITER, 1e3, 1e-6));*/
		cv::Ptr<cv::ml::TrainData> trainData = cv::ml::TrainData::create(trainingInput, cv::ml::ROW_SAMPLE, trainingLabels);
		//svm->train(trainData);
		knn->train(trainData);
		std::cout << "\n" << "kNearest trained" << "\n";
		std::cout << "\n" << "Saving kNearest" << "\n";
		knn->save("220720-kNN.xml");
		std::cout << "\n" << "kNearest saved" << "\n";
	}

	//Test section of the BoW algo
	if (executionCode == 3)
	{
		bowTest();
	}
}

void bowTest()
{
	cv::Ptr<cv::ml::KNearest> knn = cv::ml::KNearest::load("220720-kNN.xml");
	cv::Mat testImg = imread("D:\\Desktop2\\MAGISTRALE\\Primo_anno-secondo_semestre\\ComputerVision\\0FinalProject\\_LABELLED_SAMPLES\\CARDS_COURTYARD_B_T\\frame_0011.jpg", cv::IMREAD_GRAYSCALE);

	//Compute testImage histogram
	cv::Ptr<cv::SiftDescriptorExtractor> extractor = cv::SiftDescriptorExtractor::create();
	std::vector<cv::KeyPoint> keyPoints;
	cv::Mat descriptor;
	//detects features
	extractor->detect(testImg, keyPoints);
	//Computes the descriptors for a set of keypoints detected in an image
	extractor->compute(testImg, keyPoints, descriptor);
	cv::Mat imgHist = computeTestHistogram(descriptor);
	bool it = knn->isTrained();
	std::cout<<"\n" <<it <<"\n";
	cv::Mat result = cv::Mat::zeros(1, 50, CV_32F);
	float resultfloat= knn->findNearest(imgHist, 50,result);

	cv::FileStorage fs("knnresult.yml", cv::FileStorage::WRITE);
	fs << "knnvector" << result;
	fs.release();
}

cv::Mat computeTestHistogram(cv::Mat descriptor)
{
	cv::Ptr<cv::DescriptorMatcher> matcher = cv::FlannBasedMatcher::create();

	cv::FileStorage fs("bag-of-words.yml", cv::FileStorage::READ);
	cv::Mat bow;
	fs["vocabulary"] >> bow;
	fs.release();

	std::vector<cv::DMatch> matches;
	matcher->match(descriptor, bow, matches);
	cv::Mat histogram = cv::Mat::zeros(1, bow.rows, CV_32F);
	int index = 0;
	for (std::vector<cv::DMatch>::iterator k = matches.begin(); k < matches.end(); k++, index++)
	{
		histogram.at<float>(0, matches.at(index).trainIdx) += 1.0;
	}
	return histogram;
}

