#ifndef UTIL_H
#define UTIL_H



#include <iostream>
#include <fstream>
#include <string>

int checkInput(int argc, char** argv);
#endif // !UTIL_H