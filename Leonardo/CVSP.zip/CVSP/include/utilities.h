#pragma once

#include <iostream>
#include <fstream>
#include <string>

int checkInput(int argc, char** argv);