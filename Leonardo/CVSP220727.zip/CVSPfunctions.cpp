#include "CVSPfunctions.h"

cv::Mat meanshift(cv::Mat img)
{
    // Setup the termination criteria, either 10 iteration or move by atleast 1 pt
   
    cv::Mat dst;
    //cv::Mat src = img(rect);
    
    cv::pyrMeanShiftFiltering(img, dst,5, 5, 1);
    return dst;
   
    /*dst.copyTo(img(rect));

    cv::imshow("result", img);
    cv::waitKey(0);*/
}

cv::Mat floodfill(cv::Mat img, cv::Rect rect, cv::Scalar colour)
{
    cv::Mat empty;
    cv::Mat dst = meanshift(img(rect));
    cv::Point seed(floor(dst.rows / 2), floor(dst.cols / 2));
    cv::Scalar lodiff(5, 5, 5);
    cv::Scalar updiff(25, 25, 25);
    cv::floodFill(dst, empty, seed, colour,0,lodiff, updiff );
   /* cv::imshow("flooded", dst);
    cv::waitKey(0);*/
    return dst;
}

cv::Mat removeBG(cv::Mat img)
{
    // Params
    // Good params: th1:10, th2:50
    double th1 = 10;
    double th2 = 50;

    // detect edges
    cv::Mat edges;
	cv::GaussianBlur(img, img, cv::Size(3, 3),1,1);
    cv::Canny(img, edges, th1, th2);
    cv::dilate(edges, edges, cv::Mat());
    cv::erode(edges, edges, cv::Mat());
    /*cv::imshow("edges", edges);
    cv::waitKey(0);*/

    // find contours
    std::vector<std::vector<cv::Point>> contours;
    //cv::Mat contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(edges, contours, hierarchy, cv::RetrievalModes::RETR_LIST, cv::ContourApproximationModes::CHAIN_APPROX_NONE);
    int contoursIdx = 0;
    double maxArea = 0.0;
    for (int i = 0; i < contours.size(); i++)
    {
        double tmp = cv::contourArea(contours[i]);
        if (tmp > maxArea)
        {
            contoursIdx = i;
            maxArea = tmp;
        }
    }
    cv::Mat mask = cv::Mat::zeros(edges.rows, edges.cols, CV_8UC3);
    
    cv::drawContours(mask, contours, contoursIdx, cv::Scalar(255, 255, 255), -1);
    /*cv::imshow("mask", mask);
    cv::waitKey(0);*/
    return mask;
}

void findHands(cv::Mat testimg, cv::Mat hand_img, std::vector<cv::Scalar> colours)
{
    std::vector<cv::Mat> handVector;
    handVector.push_back(hand_img);
    //Obtain rotated versions of the hand
    for (int i = 0; i < 3; i++)
    {
        cv::rotate(hand_img, hand_img, cv::ROTATE_90_CLOCKWISE);
        handVector.push_back(hand_img);
    }

    std::string fn = "01.jpg";
    cv::Mat mask = removeBG(testimg);
    cv::Mat img;
    cv::Mat tmp, res;
    testimg.copyTo(img, mask);
    //img = meanshift(img);
    //cv::Mat img = meanshift(iimg);

    // Vector to store every rect (bb) found by the cascade of classifiers 
    std::vector<cv::Rect> hands = cascade(img); //temp_hands

    // Vector to store only the correct rects, which will be applied to the test image
    std::vector<cv::Rect> rectVector;
	std::vector<float> outputVector;
	// Index of the best bb
	int bbIndex = 0;
	// "Accuracy" of the best bounding box
	double maxvalue = 0.0;
	for (int i = 0; i < handVector.size(); i++)
	{
		outputVector = correctBB(img, hands, handVector[i]);
		if (outputVector[1] > maxvalue)
		{
			bbIndex = (int)outputVector[0];
			maxvalue = outputVector[1];
		}
	}

	// Check if the accuracy is too low
	if (maxvalue < 0.1)
	{
		//return 0;
	}
	maxvalue = 0.0;
	// Image that will be modified in order to hide the part of the image where the best bb is
	//This is done because in this way the cascade will not find the same bb again
	cv::Mat modimg = img.clone();

	rectVector.push_back(hands[bbIndex]);

	cv::rectangle(modimg, hands[bbIndex], cv::Scalar(0, 0, 0), -1);

	std::vector<cv::Rect>hand2 = cascade(modimg);

	// Number of hands
	int counter = 1;

	while (hand2.size() > 0 || counter != 4)
	{
		// Used for imshow
		maxvalue = 0.0;
		for (int i = 0; i < handVector.size(); i++)
		{
			outputVector = correctBB(modimg, hand2, handVector[i]);
			if (outputVector[1] > maxvalue)
			{
				bbIndex = (int)outputVector[0];
				maxvalue = outputVector[1];
			}
		}

		if (maxvalue < 0.1)
		{
			break;
		}
		else
		{
			/*for (int i = 0; i < rectVector.size(); i++)
			{
				cv::Rect intersection = rectVector[i] & hand2[bbIndex];
				double area = intersection.width * intersection.height;
				if (area > 0)
				{
					hand2[bbIndex] = rectVector[i] | hand2[bbIndex];
					rectVector.push_back(hand2[bbIndex]);
					break;
				}
			}*/
			cv::rectangle(modimg, hand2[bbIndex], cv::Scalar(255, 255, 255), -1);
			rectVector.push_back(hand2[bbIndex]);
		}
		hand2 = cascade(modimg);
		counter++;
		if (counter == 4)
		{
			break;
		}
	}

	// Draw bb
	for (int i = 0; i < rectVector.size(); i++)
	{
		cv::rectangle(img, rectVector[i], cv::Scalar(0, 255, 0));
	}

	// Color hands
	for (int i = 0; i < rectVector.size(); i++)
	{
		cv::Mat floodedRect = floodfill(img, rectVector[i], colours[i]);
		floodedRect.copyTo(img(rectVector[i]));
		cv::imshow("Flooded", img);
		cv::waitKey(0);
	}

	cv::imshow("Final result", img);
	cv::waitKey(0);
}

std::vector<float> hog(cv::Mat img)
{
	cv::HOGDescriptor hog = cv::HOGDescriptor::HOGDescriptor();
	std::vector<float> descriptor;
	hog.compute(img, descriptor);

	return descriptor;
}

float computeIoU(std::vector<cv::Rect> hands, std::string path)
{
	if (hands.size() == 0)
	{
		return 0.0;
	}

	// get the file
	std::ifstream infile(path);
	
	std::vector<cv::Rect> correctRects;
	// variables to store info in the file
	int  x=0 , y=0, width =0, height=0;
	// create a rect for each line and store it
	while (infile >> x >> y >> width >> height)
	{	
		cv::Rect bb(x, y, width, height);
		correctRects.push_back(bb);
		
	}
	// will be used for the final calculation of the IoU
	
	float IoU = 0.0;
	
	for (int i = 0; i < correctRects.size(); i++)
	{
		float ithIoU = 0.0;
		for (int j = 0; j < hands.size(); j++)
		{
			cv::Rect Intersection = correctRects[i] & hands[j];
			cv::Rect Union = correctRects[i] | hands[j];

			int areaI = Intersection.area();
			if (areaI == 0) continue;

			int areaU = Union.area();

			float tmpIoU = areaI /(float) areaU;
			if (tmpIoU > ithIoU)
			{
				ithIoU = tmpIoU;
			}
		}
		IoU += ithIoU;
	}
	IoU = IoU / correctRects.size();
	return IoU;
		
	
	

}